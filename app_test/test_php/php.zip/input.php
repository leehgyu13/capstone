<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
    </head>   
    <body>
        <form action="insert.php" method="GET">
            <p>ParkID : <input type="text" id="ParkID" name="ParkID"></p>
            <p>CarID : <input type="text" id="CarID" name="CarID"></p>
            <p>CarExist : <input type="text" id="CarExist" name="CarExist"></p>
            <p>Chargestatus : <input type="text" id="Chargestatus" name="Chargestatus"></p>
            <p><input type="submit" /></p>            
        </form>
    </body>
</html>